# Code du groupe 0 : Chuck Norris, Dwayne Johnson

def convertir(nombre, baseInitiale, baseFinale):
    return "-1"
